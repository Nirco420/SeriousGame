# Vollständiges Klassendiagramm

Stand: 16. November 2026. Alle eigenen Klassen und Enums mit sämtlichen erfassten Feldern, Properties, Events und Methoden; wegen der Größe primär als zoombare Mermaid-Quelle gedacht.

[Legende und Einordnung](README.md) · [SVG öffnen](07-Vollstaendiges-Klassendiagramm.svg) · [Offline-Ansicht](UML.html)

```mermaid
classDiagram
direction LR
class BuildingModel {
  <<MonoBehaviour>>
  -GameObject wrapper
  -BuildingData buildingData
  +BuildingData Data
  +float rotation
  -BuildingShapeUnit[] shapeUnits
  -Renderer[] renderers
  -Material[][] originalMaterials
  -Material previewMaterial
  -ResourceProduction production
  -bool isPreview
  -bool isPlaced
  +Awake() void
  +BeginPreview() void
  +SetPreviewMaterial(Material material) void
  +CompletePlacement(GridManager targetGrid, SegmentStorage segmentStorage) bool
  +Rotate(float rotationStep) void
  +GetAllBuildingPositions() List~Vector3~
}
class BuildingPlacement {
  <<MonoBehaviour>>
  -Camera mainCamera
  -InputManager inputManager
  -BuildingUI buildingUI
  -Material positive
  -Material negative
  -MainStorrage mainStorrage
  -SegmentRotation segmentRotation
  -GameObject placementPanel
  -Button confirmButton
  -Button cancelButton
  -Button rotateButton
  -BuildingModel currentPreview
  -ResourceData buildingResource
  -bool isDragging
  -GridManager grid
  -MeshCollider meshCollider
  -SegmentStorage segmentStorage
  +bool isPlacing
  +Start() void
  -OnEnable() void
  -Update() void
  -CanclePlacement() void
  -RotatePreview() void
  +OnTouchBegan(Vector2 pos) void
  +OnTouchMoved(Vector2 pos) void
  +OnTouchEnded(Vector2 pos) void
  +GetSelectedBuilding(BuildingModel buildingPrefab) void
  +PlaceBuilding() void
  -ClearPreview() void
  -OnDisable() void
}
class BuildingShapeUnit {
  <<MonoBehaviour>>
}
class BuildingStartPlacement {
  <<MonoBehaviour>>
  -BuildingModel building
  -GridManager grid
  -SegmentStorage segmentStorage
  -SnapToGrid() void
  -Start() void
}
class MainStorrage {
  <<MonoBehaviour>>
  +int wood
  +int wheed
  +int flachs
  +int gold
  -int startWood
  -int startWheed
  -int startFlachs
  -int startGold
  +Start() void
  +AddResources(int amount, ResourceData resource) void
  +RemoveResource(int amount, ResourceData resource) void
  +HasResources(int amount, ResourceData resource) bool
}
class ResourceProduction {
  <<MonoBehaviour>>
  -SegmentStorage producerForStorage
  -int productionQuantity
  -ResourceData producedResource
  -ResourceDisplayUI displayUI
  +Setup(BuildingData buildingData, SegmentStorage segmentStorage) void
  +ProduceResource() void
  +OnDestroy() void
}
class SegmentStorage {
  <<MonoBehaviour>>
  -BuildingData buildingData
  +ResourceData storedResource
  -List~ResourceProduction~ resourceBuildings
  +int currentAmount
  +int maxCapacity
  +int assignedCarts
  +Awake() void
  +AddResources(int amount) void
  +RemoveResources(int amount) int
  +RegisterProducer(ResourceProduction productionBuilding) void
  +RemoveProducer(ResourceProduction productionBuilding) void
  +ProducePerRound() void
  +AssignCart() bool
  +RemoveCarts() bool
}
class DemendManger {
  <<MonoBehaviour>>
  +event Action OnDemandDisplayRequested
  +event Action OnDemandCompleted
  -List~DemandData~ demands
  -MainStorrage mainStorrage
  -BarometerManager barometerManager
  -DemandData currentDemend
  -int nextDemandIndex
  -int dueRound
  -int latestRound
  +TriggerDemand(DemandData demand, int currentRound) void
  +CheckDemandsForRound(int currentRound) void
  +GiveAll() void
  +GiveHalf() void
  +MoreTime() void
  +HasActiveDemand() bool
  +CanGiveAll() bool
  +CanGiveHalf() bool
  -CompleteDemand() void
  +GetRemainingRounds() int
}
class RoundManager {
  <<MonoBehaviour>>
  -BuildingUI ui
  -List~SegmentStorage~ storages
  -DemendManger demendManger
  +int currentRound
  -List~TransportManager~ transports
  -OnEnable() void
  +StartNextRound(bool isRoundFinished) void
  -OnDisable() void
}
class Segment {
  <<MonoBehaviour>>
  +GridManager grid
  +MeshCollider surface
  +SegmentStorage segmentStorage
  +ResourceData allowedResources
  +Transform buildingParents
}
class SegmentRotation {
  <<MonoBehaviour>>
  -InputManager inputManager
  -float rotationStep
  -float rotationDuration
  -BuildingPlacement buildingPlacement
  -GameObject rotationPivot
  -BuildingUI buildingUI
  -Segment[] segments
  -int currentSegmentIndex
  +Segment currentSegment
  +bool isRotating
  -OnEnable() void
  -RotateOnSwipe(int amount) void
  -Rotate(int amount) IEnumerator
  -OnDisable() void
}
class GridManager {
  <<MonoBehaviour>>
  -int width
  -int height
  -float cellSize
  -MeshCollider meshCollider
  -BuildingGridCell[,] grid
  +bool IsReady
  -Awake() void
  +GridToWorldPosition(int x, int z) Vector3
  +WorldToGridPosition(Vector3 worldPos) ValueTuple
  +TrySetBuilding(BuildingModel building, List~Vector3~ allBuildingPositions) bool
  +CanBuild(List~Vector3~ allBuildingPositions) bool
  +OnDrawGizmos() void
  +IsCellOnCollider(int x, int z) bool
  +GridToWorldCenterPosition(int x, int z) Vector3
}
class BuildingGridCell {
  -BuildingModel building
  -bool isBuildable
  +SetBuilding(BuildingModel building) void
  +SetBuildable(bool isBuild) void
  +GetBuildable() bool
  +IsEmpty() bool
}
class InputManager {
  <<MonoBehaviour>>
  +event Action~Vector2~ OnFingerMoved
  +event Action~Vector2~ OnFingerBegan
  +event Action~Vector2~ OnFingerEnded
  +event Action~int~ OnSwipe
  +event Action~Vector2~ OnTap
  -float swipeRange
  -OnEnable() void
  -Update() void
  +TrackFingerPosition(Touch touch) Vector2
  +TrackFingerStartPosition(Touch touch) Vector2
  +TrackFingerEndPosition(Touch touch) Vector2
  +OnDisable() void
}
class BuildingData {
  <<ScriptableObject>>
  +string description
  +ResourceData costResource
  +int cost
  +BuildingType type
  +ResourceData resource
  +int resourceQuantity
  +int maxStorage
}
class BuildingData_BuildingType["BuildingData.BuildingType"]
class BuildingData_BuildingType {
  <<enumeration>>
  None
  STORAGE
  PRODUKTION
  RESOURECES
}
class DemandData {
  <<ScriptableObject>>
  +string name
  +string description
  +ResourceData resource
  +int quantity
  +int triggerRound
  +int deadline
  +int deferralPeriod
  +int changeInValuePositive
  +int changeInValueHalf
  +int changeInValueNegative
  +int changeInDeferalInValue
}
class ResourceData {
  <<ScriptableObject>>
  +ResourceType resourceType
  +string name
  +Sprite icon
}
class ResourceData_ResourceType["ResourceData.ResourceType"]
class ResourceData_ResourceType {
  <<enumeration>>
  None
  WOOD
  WHEED
  FLACHS
}
class CartManager {
  <<MonoBehaviour>>
  -int totalCarts
  +int TotalCarts
  +int availableCarts
  -Awake() void
  +AssignCart(SegmentStorage storage) bool
  +RemoveCart(SegmentStorage storage) bool
}
class TransportManager {
  <<MonoBehaviour>>
  -SegmentStorage segmentStorage
  -MainStorrage mainStorage
  -Transform startStoragPos
  -Transform mainStoragePos
  -GameObject cart
  -SplineAnimate splineAnimate
  -ResourceDisplayUI resourceDisplayUI
  -int transportCapacity
  +int currentLoad
  +float moveSpeed
  -bool isDriving
  +ResourceData resourceData
  -Update() void
  +StartTransport() void
  +MoveToMainStorage(float kmh) IEnumerator
  +MoveBackToSegmentStorage(float kmh) IEnumerator
  +TranportLifeCycle(Transform startPos, Transform targetPos, float kmh) IEnumerator
}
class BarometerManager {
  <<MonoBehaviour>>
  -float cellSize
  -RectTransform circle
  -Vector2 middlePosition
  -float duration
  -bool isGameOver
  -int currentValue
  +Awake() void
  +UpdateBarometer() void
  +MoveCircle() IEnumerator
  +ChangeValue(int amount) void
}
class BuildingUI {
  <<MonoBehaviour>>
  +event Action~BuildingModel~ OnBuildingSelected
  +event Action~bool~ OnNextRoundPressed
  -Button buildingButton
  -GameObject buildingPanel
  -SegmentRotation segmentRotation
  -Button building1
  -Button building2
  -Button building3
  -Button nextRound
  -BuildingModel building1x1
  -BuildingModel building2x2
  -BuildingModel building3x3
  -TextMeshProUGUI text1x1Building
  -TextMeshProUGUI text2x2Building
  -TextMeshProUGUI text3x3Building
  -Image resourceImage1x1
  -Image resourceImage2x2
  -Image resourceImage3x3
  -BuildingModel wheedBuilding
  -BuildingModel woodBuilding
  -BuildingModel flachsBuilding
  +Start() void
  +OnBuildingButtonClicked() void
  +BuildingFinished() void
  +OnBuilding1Clicked() void
  +OnBuilding2Clicked() void
  +OnBuilding3Clicked() void
  +OnEndRoundWasClicked() void
  +ShowCostBuilding(BuildingData buildingData, TextMeshProUGUI text, Image image) void
  +RefreshUiButtons() void
}
class DemandEntryUI {
  <<MonoBehaviour>>
  -TextMeshProUGUI demandResource
  -TextMeshProUGUI demandTitle
  -TextMeshProUGUI quanatityText
  -TextMeshProUGUI remainingRoundsLeft
  -Button giveAll
  -Button giveHalf
  -Button aufschub
  -DemendManger demandManager
  +Setup(DemandData currentDemand, int remainingRounds, DemendManger manager) void
  -Update() void
}
class DemendUI {
  <<MonoBehaviour>>
  -DemendManger demendManger
  -GameObject demandPanel
  -TextMeshProUGUI headlineText
  -TextMeshProUGUI descriptionText
  -TextMeshProUGUI resourceName
  -TextMeshProUGUI demandQuantity
  -TextMeshProUGUI demandDeadline
  -Button closeButton
  -Button openDemandEntry
  -DemandEntryUI demandEntryUI
  -Transform content
  -GameObject redInfo
  -GameObject demandOverview
  -DemandData demandData
  -ResourceData resourceData
  -DemandEntryUI demandEntry
  -bool currentState
  -OnEnable() void
  +Start() void
  +DemandPopUP(DemandData currentDemand, int currentRound) void
  +ClosePopUp() void
  +OpenDemandOverview() void
  -RemoveDemandEntry() void
  -OnDisable() void
}
class ResourceDisplayUI {
  <<MonoBehaviour>>
  -Image resourceIcon
  -TextMeshProUGUI quantity
  +SetResource(ResourceData resource) void
  +SetQuantity(int amount) void
}
class SegmentStorageUI {
  <<MonoBehaviour>>
  -GameObject segmentStorageUi
  -Image resourceImage
  -TextMeshProUGUI amountText
  -Button closeButton
  -CartManager cartManager
  -Vector3 panelOffset
  -InputManager inputManager
  -Camera mainCamera
  -Button cartSlot1
  -Button cartSlot2
  -Button cartSlot3
  -Sprite slotEmpty
  -Sprite slotFull
  -SegmentStorage segmentStorage
  +OnEnable() void
  +Start() void
  +OpenUI(Vector2 pos) void
  +CloseUI() void
  -GetStorageAtPosition(Vector2 pos) SegmentStorage
  -ToggleCart(int slot) void
  -RefreshCartButtons() void
  +OnDisable() void
}
class UIOverview {
  <<MonoBehaviour>>
  -MainStorrage mainStorrage
  -RoundManager roundManager
  -CartManager cartManager
  -TextMeshProUGUI flachsText
  -TextMeshProUGUI wheedText
  -TextMeshProUGUI woodText
  -TextMeshProUGUI currentRound
  -TextMeshProUGUI availabelCarts
  +Update() void
}
class SplineAnimate {
  <<external>>
}
class ProjectFolderColors {
  <<static>>
  -Dictionary ColorCache$
  -KeyValuePair[] Rules$
  -ProjectFolderColors()$
  -Rule(string path, Color color) KeyValuePair$
  -ClearCache() void$
  -GetFolderColor(string guid) Color?$
  -DrawFolder(string guid, Rect selectionRect) void$
}
class EditorApplication {
  <<external>>
}
class NewTestScript {
  +TwoPlusTwo() void
}
class Assert {
  <<external>>
}
BuildingModel --> "0..*" BuildingShapeUnit : shapeUnits
BuildingModel --> "0..1" ResourceProduction : production
BuildingModel --> BuildingData : buildingData, Data
BuildingPlacement --> "0..1" BuildingModel : currentPreview
BuildingPlacement --> MainStorrage : mainStorrage
BuildingPlacement --> SegmentStorage : segmentStorage
BuildingPlacement --> SegmentRotation : segmentRotation
BuildingPlacement --> GridManager : grid
BuildingPlacement --> InputManager : inputManager
BuildingPlacement --> ResourceData : buildingResource (ungenutzt)
BuildingPlacement --> BuildingUI : buildingUI
BuildingStartPlacement --> BuildingModel : building
BuildingStartPlacement --> SegmentStorage : segmentStorage
BuildingStartPlacement --> GridManager : grid
ResourceProduction --> SegmentStorage : producerForStorage
ResourceProduction --> ResourceData : producedResource
ResourceProduction --> ResourceDisplayUI : displayUI
SegmentStorage --> "0..*" ResourceProduction : resourceBuildings
SegmentStorage --> BuildingData : buildingData
SegmentStorage --> ResourceData : storedResource
DemendManger --> MainStorrage : mainStorrage
DemendManger --> "0..*" DemandData : demands
DemendManger --> "0..1" DemandData : currentDemend
DemendManger --> BarometerManager : barometerManager
RoundManager --> "0..*" SegmentStorage : storages
RoundManager --> DemendManger : demendManger
RoundManager --> "0..*" TransportManager : transports
RoundManager --> BuildingUI : ui
Segment --> SegmentStorage : segmentStorage
Segment --> GridManager : grid
Segment --> ResourceData : allowedResources
SegmentRotation --> BuildingPlacement : buildingPlacement
SegmentRotation --> "0..*" Segment : segments, currentSegment
SegmentRotation --> InputManager : inputManager
SegmentRotation --> BuildingUI : buildingUI
GridManager *-- "0..*" BuildingGridCell : grid
BuildingGridCell --> "0..1" BuildingModel : building
BuildingData ..> BuildingData_BuildingType : type
BuildingData --> ResourceData : costResource, resource
DemandData --> ResourceData : resource
ResourceData ..> ResourceData_ResourceType : resourceType
TransportManager --> MainStorrage : mainStorage
TransportManager --> SegmentStorage : segmentStorage
TransportManager --> ResourceData : resourceData
TransportManager --> ResourceDisplayUI : resourceDisplayUI
BuildingUI --> BuildingModel : building1x1, building2x2, building3x3, wheedBuilding, woodBuilding, flachsBuilding
BuildingUI --> SegmentRotation : segmentRotation
DemandEntryUI --> DemendManger : demandManager
DemendUI --> DemendManger : demendManger
DemendUI --> DemandData : demandData
DemendUI --> ResourceData : resourceData
DemendUI --> DemandEntryUI : demandEntryUI - Prefab
DemendUI --> "0..1" DemandEntryUI : demandEntry - Instanz
SegmentStorageUI --> SegmentStorage : segmentStorage
SegmentStorageUI --> InputManager : inputManager
SegmentStorageUI --> CartManager : cartManager
UIOverview --> MainStorrage : mainStorrage
UIOverview --> RoundManager : roundManager
UIOverview --> CartManager : cartManager
BuildingModel ..> GridManager : CompletePlacement / TrySetBuilding
BuildingModel ..> SegmentStorage : CompletePlacement / Setup
BuildingPlacement ..> BuildingData : liest Data und Baukosten
BuildingPlacement ..> Segment : liest aktuelles Segment
BuildingUI ..> BuildingData : ShowCostBuilding / Data
BuildingUI ..> ResourceData : vergleicht allowedResources und Icons
GridManager ..> BuildingModel : TrySetBuilding
ResourceProduction ..> BuildingData : Setup
SegmentStorage ..> BuildingModel : GetComponent / Data
MainStorrage ..> ResourceData : Ressourcentyp in Methoden
CartManager ..> SegmentStorage : AssignCart / RemoveCart
DemandEntryUI ..> DemandData : Setup
ResourceDisplayUI ..> ResourceData : SetResource
BuildingPlacement ..> InputManager : abonniert OnFingerBegan/Moved/Ended
SegmentRotation ..> InputManager : abonniert OnSwipe
SegmentStorageUI ..> InputManager : abonniert OnTap
BuildingPlacement ..> BuildingUI : abonniert OnBuildingSelected
RoundManager ..> BuildingUI : abonniert OnNextRoundPressed
DemendUI ..> DemendManger : abonniert OnDemandDisplayRequested / OnDemandCompleted
TransportManager --> SplineAnimate : splineAnimate
ProjectFolderColors ..> EditorApplication : abonniert Editor-Callbacks
NewTestScript ..> Assert : AreEqual
MonoBehaviour <|-- BuildingModel
MonoBehaviour <|-- BuildingPlacement
MonoBehaviour <|-- BuildingShapeUnit
MonoBehaviour <|-- BuildingStartPlacement
MonoBehaviour <|-- MainStorrage
MonoBehaviour <|-- ResourceProduction
MonoBehaviour <|-- SegmentStorage
MonoBehaviour <|-- DemendManger
MonoBehaviour <|-- RoundManager
MonoBehaviour <|-- Segment
MonoBehaviour <|-- SegmentRotation
MonoBehaviour <|-- GridManager
MonoBehaviour <|-- InputManager
ScriptableObject <|-- BuildingData
ScriptableObject <|-- DemandData
ScriptableObject <|-- ResourceData
MonoBehaviour <|-- CartManager
MonoBehaviour <|-- TransportManager
MonoBehaviour <|-- BarometerManager
MonoBehaviour <|-- BuildingUI
MonoBehaviour <|-- DemandEntryUI
MonoBehaviour <|-- DemendUI
MonoBehaviour <|-- ResourceDisplayUI
MonoBehaviour <|-- SegmentStorageUI
MonoBehaviour <|-- UIOverview
style BuildingModel fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingPlacement fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingShapeUnit fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingStartPlacement fill:#dcfce7,stroke:#475569,color:#0f172a
style MainStorrage fill:#fef3c7,stroke:#475569,color:#0f172a
style ResourceProduction fill:#fef3c7,stroke:#475569,color:#0f172a
style SegmentStorage fill:#fef3c7,stroke:#475569,color:#0f172a
style DemendManger fill:#fce7f3,stroke:#475569,color:#0f172a
style RoundManager fill:#e0f2fe,stroke:#475569,color:#0f172a
style Segment fill:#e0f2fe,stroke:#475569,color:#0f172a
style SegmentRotation fill:#e0f2fe,stroke:#475569,color:#0f172a
style GridManager fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingGridCell fill:#dcfce7,stroke:#475569,color:#0f172a
style InputManager fill:#e0f2fe,stroke:#475569,color:#0f172a
style BuildingData fill:#ede9fe,stroke:#475569,color:#0f172a
style DemandData fill:#ede9fe,stroke:#475569,color:#0f172a
style ResourceData fill:#ede9fe,stroke:#475569,color:#0f172a
style CartManager fill:#fef3c7,stroke:#475569,color:#0f172a
style TransportManager fill:#fef3c7,stroke:#475569,color:#0f172a
style BarometerManager fill:#fce7f3,stroke:#475569,color:#0f172a
style BuildingUI fill:#e0f2fe,stroke:#475569,color:#0f172a
style DemandEntryUI fill:#fce7f3,stroke:#475569,color:#0f172a
style DemendUI fill:#fce7f3,stroke:#475569,color:#0f172a
```
