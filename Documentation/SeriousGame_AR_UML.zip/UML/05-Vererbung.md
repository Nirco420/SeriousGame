# Vollständige Vererbung der Laufzeitklassen

Stand: 16. November 2026. 22 eigene MonoBehaviours, drei ScriptableObjects und die gewöhnliche C#-Klasse BuildingGridCell. Zwischen den eigenen Laufzeitklassen gibt es keine Vererbung.

[Legende und Einordnung](README.md) · [SVG öffnen](05-Vererbung.svg) · [Offline-Ansicht](UML.html)

```mermaid
classDiagram
direction LR
class BuildingModel {
  <<MonoBehaviour>>
}
class BuildingPlacement {
  <<MonoBehaviour>>
}
class BuildingShapeUnit {
  <<MonoBehaviour>>
}
class BuildingStartPlacement {
  <<MonoBehaviour>>
}
class MainStorrage {
  <<MonoBehaviour>>
}
class ResourceProduction {
  <<MonoBehaviour>>
}
class SegmentStorage {
  <<MonoBehaviour>>
}
class DemendManger {
  <<MonoBehaviour>>
}
class RoundManager {
  <<MonoBehaviour>>
}
class Segment {
  <<MonoBehaviour>>
}
class SegmentRotation {
  <<MonoBehaviour>>
}
class GridManager {
  <<MonoBehaviour>>
}
class BuildingGridCell {
}
class InputManager {
  <<MonoBehaviour>>
}
class BuildingData {
  <<ScriptableObject>>
}
class DemandData {
  <<ScriptableObject>>
}
class ResourceData {
  <<ScriptableObject>>
}
class CartManager {
  <<MonoBehaviour>>
}
class TransportManager {
  <<MonoBehaviour>>
}
class BarometerManager {
  <<MonoBehaviour>>
}
class BuildingUI {
  <<MonoBehaviour>>
}
class DemandEntryUI {
  <<MonoBehaviour>>
}
class DemendUI {
  <<MonoBehaviour>>
}
class ResourceDisplayUI {
  <<MonoBehaviour>>
}
class SegmentStorageUI {
  <<MonoBehaviour>>
}
class UIOverview {
  <<MonoBehaviour>>
}
MonoBehaviour <|-- BuildingModel
MonoBehaviour <|-- BuildingPlacement
MonoBehaviour <|-- BuildingShapeUnit
MonoBehaviour <|-- BuildingStartPlacement
MonoBehaviour <|-- MainStorrage
MonoBehaviour <|-- ResourceProduction
MonoBehaviour <|-- SegmentStorage
MonoBehaviour <|-- DemendManger
MonoBehaviour <|-- RoundManager
MonoBehaviour <|-- Segment
MonoBehaviour <|-- SegmentRotation
MonoBehaviour <|-- GridManager
MonoBehaviour <|-- InputManager
ScriptableObject <|-- BuildingData
ScriptableObject <|-- DemandData
ScriptableObject <|-- ResourceData
MonoBehaviour <|-- CartManager
MonoBehaviour <|-- TransportManager
MonoBehaviour <|-- BarometerManager
MonoBehaviour <|-- BuildingUI
MonoBehaviour <|-- DemandEntryUI
MonoBehaviour <|-- DemendUI
MonoBehaviour <|-- ResourceDisplayUI
MonoBehaviour <|-- SegmentStorageUI
MonoBehaviour <|-- UIOverview
style BuildingModel fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingPlacement fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingShapeUnit fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingStartPlacement fill:#dcfce7,stroke:#475569,color:#0f172a
style MainStorrage fill:#fef3c7,stroke:#475569,color:#0f172a
style ResourceProduction fill:#fef3c7,stroke:#475569,color:#0f172a
style SegmentStorage fill:#fef3c7,stroke:#475569,color:#0f172a
style DemendManger fill:#fce7f3,stroke:#475569,color:#0f172a
style RoundManager fill:#e0f2fe,stroke:#475569,color:#0f172a
style Segment fill:#e0f2fe,stroke:#475569,color:#0f172a
style SegmentRotation fill:#e0f2fe,stroke:#475569,color:#0f172a
style GridManager fill:#dcfce7,stroke:#475569,color:#0f172a
style BuildingGridCell fill:#dcfce7,stroke:#475569,color:#0f172a
style InputManager fill:#e0f2fe,stroke:#475569,color:#0f172a
style BuildingData fill:#ede9fe,stroke:#475569,color:#0f172a
style DemandData fill:#ede9fe,stroke:#475569,color:#0f172a
style ResourceData fill:#ede9fe,stroke:#475569,color:#0f172a
style CartManager fill:#fef3c7,stroke:#475569,color:#0f172a
style TransportManager fill:#fef3c7,stroke:#475569,color:#0f172a
style BarometerManager fill:#fce7f3,stroke:#475569,color:#0f172a
style BuildingUI fill:#e0f2fe,stroke:#475569,color:#0f172a
style DemandEntryUI fill:#fce7f3,stroke:#475569,color:#0f172a
style DemendUI fill:#fce7f3,stroke:#475569,color:#0f172a
```
